#!/usr/bin/perl
#This program rum as a standalone at any Mac system
#Uses:perl valid.pl Input_fasta_file Threshold
#User can submit more than one protein sequences at a time
#Protein sequences should be in fasta format

$input_file=$ARGV[0];
system "perl fasta.pl $input_file >twoline";
system "grep '>' twoline |cut -d '|' -f3 |cut -d ' ' -f1 >protein_id";
system "perl dipep.pl twoline >dipep_comp";
system "sed -e 's/^/+1 /' dipep_comp >final";
system "svm_light/svm_classify final Models/level1_model svm_score_leve1";
system "svm_light/svm_classify final Models/level2_model_NR0 svm_score_leve2_NR0";
system "svm_light/svm_classify final Models/level2_model_NR1 svm_score_leve2_NR1";
system "svm_light/svm_classify final Models/level2_model_NR2 svm_score_leve2_NR2";
system "svm_light/svm_classify final Models/level2_model_NR3 svm_score_leve2_NR3";
system "svm_light/svm_classify final Models/level2_model_NR4 svm_score_leve2_NR4";
system "svm_light/svm_classify final Models/level2_model_NR5 svm_score_leve2_NR5";
system "svm_light/svm_classify final Models/level2_model_NR6 svm_score_leve2_NR6";

system "paste protein_id final svm_score_leve1 svm_score_leve2_NR0 svm_score_leve2_NR1 svm_score_leve2_NR2 svm_score_leve2_NR3 svm_score_leve2_NR4 svm_score_leve2_NR5 svm_score_leve2_NR6 >final_svm";
system "tr '\t' '#' <final_svm >final_pred";

open(RESULT,">>Result") or die "$!";
print RESULT "Protein ID\tPrediction\n";
close RESULT;

open(FINAL_PRED,"final_pred") or die "$!";
while($line1=<FINAL_PRED>)
{
    chomp($line1);
    #print "$line1\n";
    @svm=split(/#/,$line1);
    #print "$svm[2]\n";
    if($svm[2] < $ARGV[1])
    {
	#print "Protein belongs to Non-NR\n";
	open(RESULT,">>Result") or die "$!";
	print RESULT "$svm[0]\tNon-NR\n";
	close RESULT;
    }
    else
    {
	if(($svm[3] > $svm[4])&&($svm[3] > $svm[5])&&($svm[3] > $svm[6])&&($svm[3] > $svm[7])&&($svm[3] > $svm[8])&&($svm[3] > $svm[9]))
	{
	    #print "Protein belongs to NR0 family\n";
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR0 Subfamily\n";
	    close RESULT;
	}
	if(($svm[4] > $svm[3])&&($svm[4] > $svm[5])&&($svm[4] > $svm[6])&&($svm[4] > $svm[7])&&($svm[4] > $svm[8])&&($svm[4] > $svm[9]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR1 Subfamily\n";
	    close RESULT;
	}
	if(($svm[5] > $svm[3])&&($svm[5] > $svm[4])&&($svm[5] > $svm[6])&&($svm[5] > $svm[7])&&($svm[5] > $svm[8])&&($svm[5] > $svm[9]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR2 Subfamily\n";
	    close RESULT;
	}
	if(($svm[6] > $svm[3])&&($svm[6] > $svm[4])&&($svm[6] > $svm[5])&&($svm[6] > $svm[7])&&($svm[6] > $svm[8])&&($svm[6] > $svm[9]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR3 Subfamily\n";
	    close RESULT;
	}
	if(($svm[7] > $svm[3])&&($svm[7] > $svm[4])&&($svm[7] > $svm[5])&&($svm[7] > $svm[6])&&($svm[7] > $svm[8])&&($svm[7] > $svm[9]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR4 Subfamily\n";
	    close RESULT;
	}
	if(($svm[8] > $svm[3])&&($svm[8] > $svm[4])&&($svm[8] > $svm[5])&&($svm[8] > $svm[6])&&($svm[8] > $svm[7])&&($svm[8] > $svm[9]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR5 Subfamily\n";
	    close RESULT;
	}
	if(($svm[9] > $svm[3])&&($svm[9] > $svm[4])&&($svm[9] > $svm[5])&&($svm[9] > $svm[6])&&($svm[9] > $svm[7])&&($svm[9] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tNR6 Subfamily\n";
	    close RESULT;
	}
    }
}
system "rm final_pred final_svm protein_id twoline dipep_comp final svm_score_leve1 svm_score_leve2_NR0 svm_score_leve2_NR1 svm_score_leve2_NR2 svm_score_leve2_NR3 svm_score_leve2_NR4 svm_score_leve2_NR5 svm_score_leve2_NR6 out.fasta";
